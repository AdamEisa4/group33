Online Learning 
This is a Online Learning  web application.

Pages
The web application consists of the following pages:

Home (index.html): This is the landing page where users are welcomed and can navigate to other parts of the site.

About (about.html): This page contains information about the organization or service.

Contact Us (Contact Us.html): On this page, users can send a message to the administrators of the web app.

Teacher Directory/Search (search.html): This page allows users to search for teachers by subject and/or name. The teacher list is added dynamically using JavaScript.

Sign Up (signup.html): This page allows users to sign up for the service. They can provide their first name, last name, email, and password, and specify whether they are a student or teacher.

Requirements
To run this project, you need a modern web browser that supports ES6 (like Chrome, Firefox, Safari, or Edge).

Installation
Clone this repository to your local machine.
Open the index.html file in your web browser.
Usage
To search for a teacher, navigate to the "Teacher Directory" page by entering to your Presonal Area and use the input fields to filter the list of teachers by name or subject.
To sign up as a student or teacher, navigate to the "Sign Up" page and fill out the form.

Technologies Used
HTML
CSS
JavaScript

Styles
The styling of the web application is done using CSS. The styles can be found in the style.css file.

Scripts
The dynamic functionality of the web application (such as filtering the teacher list) is achieved using JavaScript. The scripts can be found in the script.js file.

Please note that as of now, the script.js file is included in the HTML files but is empty. The actual functionality for dynamically adding teachers to the list and other dynamic elements needs to be implemented.

Contributing
If you'd like to contribute, please fork the repository and make changes as you'd like. Pull requests are warmly welcome.

Acknowledgements
Special thanks to all the teachers who make learning possible!

Future enhancements
Implement server-side functionality to store the user and teacher data.
Implement login functionality.
Add validation for form inputs.
Implement a feature to allow students to connect with teachers.

