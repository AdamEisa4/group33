document.addEventListener('DOMContentLoaded', () => {
  const myForm = document.getElementById('myForm');
  const msg = document.getElementById('msg');
  const userList = document.getElementById('userList');
  const userListContainer = document.querySelector('.user-list-container');

  const onSubmit = (e) => {
    e.preventDefault();

    const firstNameInput = document.getElementById('firstNameInput');
    const lastNameInput = document.getElementById('lastNameInput');
    const emailInput = document.getElementById('emailInput');
    const passwordInput = document.getElementById('passwordInput');

    if (firstNameInput.value === '' || lastNameInput.value === '' || emailInput.value === '' || passwordInput.value === '') {
      showMessage('Please enter all fields', 'error');
    } else {
      const li = document.createElement('li');
      li.textContent = `${firstNameInput.value} ${lastNameInput.value}: ${emailInput.value}`;
      userList.appendChild(li);
      myForm.reset();
      showMessage('Form submitted successfully!', 'success');
      userListContainer.style.display = 'block';
    }
  };

  const showMessage = (message, className) => {
    msg.textContent = message;
    msg.classList.add(className);
    setTimeout(() => {
      msg.textContent = '';
      msg.classList.remove(className);
    }, 1000);
  };

  myForm.addEventListener('submit', onSubmit);
});
