const teacherList = [
  {
    name: "Dany Rivers",
    subject: "Differential and Integral Calculus",
    contact: "dany.rivers@example.com",
  },
  {
    name: "John Smith",
    subject: "Physics",
    contact: "john.smith@example.com",
  },
  {
    name: "Jane Doe",
    subject: "Chemistry",
    contact: "jane.doe@example.com",
  },
  {
    name: "Michael Johnson",
    subject: "Mathematics",
    contact: "michael.johnson@example.com",
  },
  {
    name: "Emma Wilson",
    subject: "Biology",
    contact: "emma.wilson@example.com",
  },
  {
    name: "Oliver Brown",
    subject: "Computer Science",
    contact: "oliver.brown@example.com",
  },
  {
    name: "Sophia Taylor",
    subject: "Psychology",
    contact: "sophia.taylor@example.com",
  },
  {
    name: "Ava Lee",
    subject: "Economics",
    contact: "ava.lee@example.com",
  },
  {
    name: "Mia Harris",
    subject: "Philosophy",
    contact: "mia.harris@example.com",
  },
  // ... Add more teachers as needed ...
];

const listElement = document.getElementById("teacherList");
const subjectFilter = document.getElementById("subjectFilter");
const nameFilter = document.getElementById("nameFilter");
const noResultsMessage = document.createElement("div");

noResultsMessage.innerHTML = `<p>No teachers found for the given search.</p>`;
noResultsMessage.style.display = "none";
listElement.appendChild(noResultsMessage);

function renderTeachers(teachers) {
  listElement.innerHTML = "";
  if (teachers.length === 0) {
    noResultsMessage.style.display = "block";
    listElement.appendChild(noResultsMessage);
    return;
  }

  teachers.forEach((teacher) => {
    const teacherBox = document.createElement("div");
    teacherBox.className = "teacher-box";
    teacherBox.innerHTML = `
      <div class="teacher-info">
        <p>Name: ${teacher.name}</p>
        <p>Subject: ${teacher.subject}</p>
        <p>Contact: <a href="mailto:${teacher.contact}">${teacher.contact}</a></p>
      </div>
      <button onclick="scheduleLesson('${teacher.name}')">Schedule Lesson</button>`;
    listElement.appendChild(teacherBox);
  });
}
subjectFilter.addEventListener("input", () => {
  const searchTerm = subjectFilter.value.toLowerCase();
  const filteredTeachers = teacherList.filter((teacher) =>
    teacher.subject.toLowerCase().includes(searchTerm)
  );
  renderTeachers(filteredTeachers);
});

nameFilter.addEventListener("input", () => {
  const searchTerm = nameFilter.value.toLowerCase();
  const filteredTeachers = teacherList.filter((teacher) =>
    teacher.name.toLowerCase().includes(searchTerm)
  );
  renderTeachers(filteredTeachers);
});

function scheduleLesson(teacherName) {
  alert(`Scheduling a lesson with ${teacherName} is not yet implemented.`);
}

// Initial render
renderTeachers(teacherList);