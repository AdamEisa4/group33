const loggedInUserCookie = getCookie("loggedInUser");
const loggedInUser = JSON.parse(loggedInUserCookie.slice(2));

fetch(`/getLessonsByStudentId?id=${loggedInUser.id}`, {
    method: "GET",
    headers: {
        "Content-Type": "application/json",
    },
})
    .then((res) => res.json())
    .then((res) => {
        if (res) {
            drawLessonsInTable(res);
        } else if (res.error) {
            console.log(res);
            alert(res.error);
        }
    });

function drawLessonsInTable(res) {
    const table = document.querySelector("table tbody");
    for (let i = 0; i < res.length; i++) {
        const row = res[i];
        console.log(row);
        let html = `
            <tr>
                <td>${toDateTime(row.date)}</td>
                <td>${row.firstname} ${row.lastname}</td>
                <td>${row.email}</td>
                <td>${row.subject}</td>
                <td><button onclick="cancel(${row.id})">Cancel</button></td>
            </tr>
        `;
        table.innerHTML += html;
    }
}

function cancel(id) {
    fetch(`/cancelLesson?id=${id}`, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        },
    }).then((res) => window.location.reload());
}

function toDateTime(date) {
    if (!date) {
        return "";
    }

    var d = new Date(date);
    var dateStr =
        ("00" + d.getDate()).slice(-2) +
        "/" +
        ("00" + (d.getMonth() + 1)).slice(-2) +
        "/" +
        d.getFullYear() +
        " " +
        ("00" + d.getHours()).slice(-2) +
        ":" +
        ("00" + d.getMinutes()).slice(-2);

    return dateStr;
}
