document.addEventListener("DOMContentLoaded", () => {
    const myForm = document.getElementById("myForm");
    const msg = document.getElementById("msg");

    const onSubmit = (e) => {
        e.preventDefault();

        const emailInput = document.getElementById("emailInput");
        const passwordInput = document.getElementById("passwordInput");

        if (validate(emailInput, passwordInput)) {
            const emailInput = document.getElementById("emailInput");
            const passwordInput = document.getElementById("passwordInput");

            let payload = {
                email: emailInput.value,
                password: passwordInput.value,
            };

            fetch("/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            })
                .then((res) => {
                    if (res?.status === 200) {
                        return res.json();
                    } else {
                        showMessage(`Failed to login`, "error");
                    }
                })
                .then((res) => {
                    if (res) {
                        console.log(res);
                        showMessage("logged in successfully!", "success");
                        setTimeout(function () {
                            window.location = "/search";
                        }, 1000);
                    } else {
                        showMessage(`Failed to login`, "error");
                    }
                })
                .catch((err) => {
                    console.log(err);
                    showMessage(
                        "no user was found for the given credentials",
                        "error"
                    );
                });
        }
    };

    const validate = (emailInput, passwordInput) => {
        if (!emailInput.value || !passwordInput.value) {
            showMessage("please enter all fields", "error");
            return false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
            showMessage("please enter a valid emaild", "error");
            return false;
        }
        return true;
    };

    const showMessage = (message, className) => {
        msg.textContent = message;
        msg.classList.add(className);
        setTimeout(() => {
            msg.textContent = "";
            msg.classList.remove(className);
        }, 5000);
    };

    myForm.addEventListener("submit", onSubmit);
});
