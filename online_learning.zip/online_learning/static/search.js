document.addEventListener("DOMContentLoaded", () => {
    const listElement = document.getElementById("teacherList");
    const subjectFilter = document.getElementById("subjectFilter");
    const nameFilter = document.getElementById("nameFilter");
    const noResultsMessage = document.createElement("div");
    const msg = document.getElementById("msg");

    noResultsMessage.innerHTML = `<p>No teachers found for the given search.</p>`;
    noResultsMessage.style.display = "none";
    listElement.appendChild(noResultsMessage);

    function renderTeachers(teachers) {
        listElement.innerHTML = "";
        if (teachers.length === 0) {
            noResultsMessage.style.display = "block";
            listElement.appendChild(noResultsMessage);
            return;
        }

        teachers.forEach((teacher) => {
            const teacherBox = document.createElement("div");
            teacherBox.className = "teacher-box";
            teacherBox.innerHTML = `
        <div class="teacher-info">
            <p>Name: ${teacher.firstname} ${teacher.lastname}</p>
            <p>Subject: ${teacher.subject}</p>
            <p>Contact: <a href="mailto:${teacher.email}">${teacher.email}</a></p>
        </div>
        <button onclick="scheduleLesson('${teacher.id}')">Schedule Lesson</button>`;
            listElement.appendChild(teacherBox);
        });
    }

    subjectFilter.addEventListener("input", () => {
        search(
            nameFilter.value?.toLowerCase(),
            subjectFilter.value?.toLowerCase()
        );
    });

    nameFilter.addEventListener("input", () => {
        search(
            nameFilter.value?.toLowerCase(),
            subjectFilter.value?.toLowerCase()
        );
    });

    function search(name, subject) {
        fetch(`/searchTeachers?name=${name}&subject=${subject}`, {
            method: "GET",
        })
            .then((response) => response.json())
            .then((response) => {
                renderTeachers(response ?? []);
            })
            .catch((err) => {
                console.log(err);
                renderTeachers([]);
            });
    }

    // Initial render
    search("", "");
});

function scheduleLesson(teacherId) {
    const loggedInUserCookie = getCookie("loggedInUser");
    const loggedInUser = JSON.parse(loggedInUserCookie.slice(2));

    fetch("/createLesson", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            studentId: Number(loggedInUser.id),
            teacherId: Number(teacherId),
            date: new Date().toJSON().slice(0, 19).replace("T", " "),
        }),
    })
        .then((res) => {
            if (res?.status === 200) {
                return res.json();
            } else {
                showMessage(`Failed to schedule a lesson`, "error");
            }
        })
        .then((res) => {
            if (res) {
                console.log(res);
                showMessage("scheduled a lesson successfully!", "success");
            } else {
                showMessage(`Failed to schedule a lesson`, "error");
            }
        })
        .catch((err) => {
            console.log(err);
            showMessage(err.message, "error");
        });
}

const showMessage = (message, className) => {
    msg.textContent = message;
    msg.classList.add(className);
    setTimeout(() => {
        msg.textContent = "";
        msg.classList.remove(className);
    }, 5000);
};
