document.addEventListener("DOMContentLoaded", () => {
    const myForm = document.getElementById("myForm");
    const msg = document.getElementById("msg");
    const type = document.getElementById("type");
    const subject = document.getElementById("subject");

    type.addEventListener("change", function (event) {
        const value = event.target.value;
        if (value === "teacher") {
            subject.style.display = "block";
        } else {
            subject.style.display = "none";
        }
    });

    const onSubmit = (e) => {
        e.preventDefault();

        const firstNameInput = document.getElementById("firstNameInput");
        const lastNameInput = document.getElementById("lastNameInput");
        const emailInput = document.getElementById("emailInput");
        const passwordInput = document.getElementById("passwordInput");
        const subjectInput = document.getElementById("subjectInput");
        const userType = document.getElementById("type").value;

        if (
            validate(
                firstNameInput,
                lastNameInput,
                emailInput,
                passwordInput,
                subjectInput,
                userType
            )
        ) {
            if (userType === "teacher" && !!subjectInput.value) {
                createNewUser("teacher");
            } else if (userType === "student") {
                createNewUser("student");
            }
        }
    };

    const validate = (
        firstNameInput,
        lastNameInput,
        emailInput,
        passwordInput,
        subjectInput,
        userType
    ) => {
        if (
            !firstNameInput.value ||
            !lastNameInput.value ||
            !emailInput.value ||
            !passwordInput.value
        ) {
            showMessage("please enter all fields", "error");
            return false;
        } else if (
            !/^[a-zA-Z\s]*$/i.test(firstNameInput.value) ||
            !/^[a-zA-Z\s]*$/i.test(lastNameInput.value)
        ) {
            showMessage(
                "only english letters are allowed for firstname & lastname",
                "error"
            );
            return false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value)) {
            showMessage("please enter a valid emaild", "error");
            return false;
        } else if (passwordInput.value.length < 6) {
            showMessage(
                "please enter a password with at least 6 characters",
                "error"
            );
            return false;
        } else if (
            userType === "teacher" &&
            (!subjectInput.value || !/^[a-zA-Z\s]*$/i.test(subjectInput.value))
        ) {
            showMessage("please enter a valid subject", "error");
            return false;
        }
        return true;
    };

    const createNewUser = (type) => {
        const firstNameInput = document.getElementById("firstNameInput");
        const lastNameInput = document.getElementById("lastNameInput");
        const emailInput = document.getElementById("emailInput");
        const passwordInput = document.getElementById("passwordInput");
        const subjectInput = document.getElementById("subjectInput");

        let payload = {
            firstname: firstNameInput.value,
            lastname: lastNameInput.value,
            email: emailInput.value,
            password: passwordInput.value,
        };
        if (type === "teacher") {
            payload.subject = subjectInput.value;
        }

        fetch(type === "teacher" ? "/createNewTeacher" : "/createNewStudent", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        })
            .then((res) => {
                if (res?.status === 200) {
                    return res.json();
                } else {
                    showMessage(`Failed to create ${type}`, "error");
                }
            })
            .then((res) => {
                if (res) {
                    console.log(res);
                    showMessage(`${type} created successfully!`, "success");
                    setTimeout(function () {
                        window.location = "login";
                    }, 1000);
                } else {
                    showMessage(`Failed to create ${type}`, "error");
                }
            })
            .catch((err) => {
                console.log(err);
                showMessage(err.message, "error");
            });
    };

    const showMessage = (message, className) => {
        msg.textContent = message;
        msg.classList.add(className);
        setTimeout(() => {
            msg.textContent = "";
            msg.classList.remove(className);
        }, 5000);
    };

    myForm.addEventListener("submit", onSubmit);
});
