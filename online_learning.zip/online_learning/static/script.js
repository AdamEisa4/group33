document.addEventListener("DOMContentLoaded", () => {
    const myLessonsListItem = document.querySelector(
        ".right-links li:nth-of-type(1)"
    );
    const searchListItem = document.querySelector(
        ".right-links li:nth-of-type(2)"
    );
    const signupListItem = document.querySelector(
        ".right-links li:nth-of-type(5)"
    );
    const loggedInUserCookie = getCookie("loggedInUser");
    if (loggedInUserCookie) {
        const loggedInUser = JSON.parse(loggedInUserCookie.slice(2));

        if (loggedInUser) {
            signupListItem.innerHTML = '<a href="logout">Logout</a>';
        } else {
            myLessonsListItem.remove();
            searchListItem.remove();
        }
    } else {
        myLessonsListItem.remove();
        searchListItem.remove();
    }
});

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
