const express = require("express");
const app = express();
const path = require("path");
const cookieParse = require("cookie-parser");
const bodyParser = require("body-parser");
const crud = require("./db/crud");
const dbInit = require("./db/init");

app.use(cookieParse());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "static")));
app.set("view engine", "pug");

app.use(express.static(path.join(__dirname, "views")));
app.use(express.static(path.join(__dirname, "static")));
app.use("/img", express.static(path.join(__dirname, "img")));

// Define APIS
app.get("/createDB", (req, res) => {
    dbInit.createDb();
    res.send("DB was created successfully");
});
app.get("/dropDB", (req, res) => {
    dbInit.dropDb();
    res.send("DB was dropped successfully");
});

// Define routes
app.get("/", (req, res) => {
    res.render("index");
});

app.get("/index", (req, res) => {
    res.render("index");
});

app.get("/login", (req, res) => {
    res.render("login");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});

app.get("/search", (req, res) => {
    res.render("search");
});

app.get("/contact-us", (req, res) => {
    res.render("contact-us");
});

app.get("/about", (req, res) => {
    res.render("about");
});

app.get("/my-lessons", (req, res) => {
    if (!req.cookies.loggedInUser) {
        res.redirect("login");
    }
    res.render("my-lessons");
});

app.post("/login", crud.login);
app.get("/logout", crud.logout);
app.get("/searchTeachers", crud.searchTeachers);
app.get("/getLessonsByStudentId", crud.getLessonsByStudentId);
app.post("/createNewStudent", crud.createNewStudent);
app.post("/createNewTeacher", crud.createNewTeacher);
app.post("/createLesson", crud.createLesson);
app.delete("/cancelLesson", crud.cancelLesson);

// Start the server
app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});
