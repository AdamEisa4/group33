module.exports = {
    HOST: "",
    USER: "root",
    PASSWORD: "",
    DB: "",
};
