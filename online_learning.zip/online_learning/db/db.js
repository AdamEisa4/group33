const mysql = require("mysql2");
const config = require("./db.config");

// create connection
const connection = mysql.createConnection({
    host: config.HOST,
    user: config.USER,
    password: config.PASSWORD,
    database: config.DB,
});

//open the connection
connection.connect((error) => {
    if (error) throw error;
    console.log("successfully connected to DB");
});

module.exports = connection;
