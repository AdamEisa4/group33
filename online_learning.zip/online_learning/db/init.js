const sql = require("./db");
const path = require("path");
const csv = require("csvtojson");

const createDb = (req, res) => {
    const query = `CREATE DATABASE IF NOT EXISTS web`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("created db web");

        createTableStudents();
        createTableTeachers();
        createTableLessons();

        insertTableStudents();
        insertTableTeachers();
        insertTableLessons();
    });
};

const dropDb = (req, res) => {
    const query = `DROP DATABASE IF EXISTS web`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("dropped db web");
        return;
    });
};

const createTableStudents = () => {
    const query = `CREATE TABLE web.students (
        id INT NOT NULL AUTO_INCREMENT,
        firstname varchar(50),
        lastname varchar(50),
        email varchar(50),
        password varchar(25),
        UNIQUE KEY email (email),
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table students");
        return;
    });
};

const createTableTeachers = () => {
    const query = `CREATE TABLE web.teachers (
        id INT NOT NULL AUTO_INCREMENT,
        firstname varchar(50),
        lastname varchar(50),
        email varchar(50),
        subject varchar(25),
        password varchar(25),
        UNIQUE KEY email (email),
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table teachers");
        return;
    });
};

const createTableLessons = () => {
    const query = `CREATE TABLE web.lessons (
        id INT NOT NULL AUTO_INCREMENT,
        studentId INT NOT NULL,
        teacherId INT NOT NULL,
        date DATETIME,
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table lessons");
        return;
    });
};

const insertTableStudents = () => {
    const csvPath = path.join(__dirname, "../csv/students.csv");
    csv()
        .fromFile(csvPath)
        .then((jsonObj) => {
            jsonObj.forEach((element) => {
                const row = {
                    id: element.id,
                    firstname: element.firstname,
                    lastname: element.lastname,
                    email: element.email,
                    password: element.password,
                };
                const q = `INSERT INTO web.students SET ?`;
                sql.query(q, row, (err, mysqlres) => {
                    if (err) {
                        throw err;
                    } else {
                        console.log("created student successfully");
                    }
                });
            });
        });
};

const insertTableTeachers = () => {
    const csvPath = path.join(__dirname, "../csv/teachers.csv");
    csv()
        .fromFile(csvPath)
        .then((jsonObj) => {
            jsonObj.forEach((element) => {
                const row = {
                    id: element.id,
                    firstname: element.firstname,
                    lastname: element.lastname,
                    email: element.email,
                    subject: element.subject,
                    password: element.password,
                };
                const q = `INSERT INTO web.teachers SET ?`;
                sql.query(q, row, (err, mysqlres) => {
                    if (err) {
                        throw err;
                    } else {
                        console.log("created teacher successfully");
                    }
                });
            });
        });
};

const insertTableLessons = () => {
    const csvPath = path.join(__dirname, "../csv/lessons.csv");
    csv()
        .fromFile(csvPath)
        .then((jsonObj) => {
            jsonObj.forEach((element) => {
                const row = {
                    id: element.id,
                    studentId: element.studentId,
                    teacherId: element.teacherId,
                    date: element.date,
                };
                const q = `INSERT INTO web.lessons SET ?`;
                sql.query(q, row, (err, mysqlres) => {
                    if (err) {
                        throw err;
                    } else {
                        console.log("created lesson successfully");
                    }
                });
            });
        });
};

module.exports = {
    createDb,
    dropDb,
};
