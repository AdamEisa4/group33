const sql = require("./db");

const login = function (req, res) {
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!",
        });
        return;
    }

    const email = req.body.email;
    const password = req.body.password;
    const q = `SELECT * from web.students WHERE email = '${email}' AND password = '${password}' LIMIT 1`;
    console.log(q);

    sql.query(q, (err, records, fields) => {
        if (err) {
            console.log("error: ", err);
            res.send(err);
        } else if (records && records[0]) {
            const user = JSON.parse(JSON.stringify(records[0]));
            console.log(user);
            res.cookie("loggedInUser", user);
            res.send(user);
        } else {
            console.log("error: ", err);
            res.send(err);
        }
    });
};

const logout = function (req, res) {
    res.clearCookie("loggedInUser");
    res.redirect("/");
};

const createNewStudent = (req, res) => {
    if (!req.body) {
        res.status(400).send("content cannot be empty");
        return;
    }
    const student = {
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        password: req.body.password,
    };
    // run insert query
    const q = "insert into web.students set ?";
    sql.query(q, student, (err, mysqlres) => {
        if (err) {
            console.log(err);
            res.status(400).send("Create new student failed");
            return;
        }
        console.log("Created new student", req.body);
        student.clientID = mysqlres.insertId;
        res.status(200).json(student);
        return;
    });
};

const createNewTeacher = (req, res) => {
    if (!req.body) {
        res.status(400).send("content cannot be empty");
        return;
    }
    const teacher = {
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        password: req.body.password,
        subject: req.body.subject,
    };
    // run insert query
    const q = "insert into web.teachers set ?";
    sql.query(q, teacher, (err, mysqlres) => {
        if (err) {
            console.log(err);
            res.status(400).send("Create new teacher failed");
            return;
        }
        console.log("Created new teacher", req.body);
        teacher.clientID = mysqlres.insertId;
        res.status(200).json(teacher);
        return;
    });
};

const searchTeachers = function (req, res) {
    const name = req.query.name;
    const subject = req.query.subject;
    const q = `SELECT id, firstname, lastname, email, subject 
    from web.teachers 
    WHERE (firstname LIKE '%${name}%' 
    OR lastname LIKE '%${name}%' 
    OR email LIKE '%${name}%') 
    AND subject LIKE '%${subject}%'`;
    console.log(q);

    sql.query(q, (err, records, fields) => {
        if (err) {
            console.log("error: ", err);
            res.send(err);
        } else if (records) {
            res.status(200).json(records);
        } else {
            console.log("error: ", err);
            res.send(err);
        }
    });
};

const getLessonsByStudentId = function (req, res) {
    const id = req.query.id;
    const q = `SELECT l.id, l.date, t.firstname, t.lastname, t.email, t.subject 
    FROM web.lessons as l 
    JOIN web.teachers as t ON l.teacherId = t.id 
    WHERE l.studentId = '${id}'`;
    console.log(q);

    sql.query(q, (err, records, fields) => {
        if (err) {
            console.log("error: ", err);
            res.send(err);
        } else if (records) {
            res.status(200).json(records);
        } else {
            console.log("error: ", err);
            res.send(err);
        }
    });
};

const createLesson = (req, res) => {
    if (!req.body) {
        res.status(400).send("content cannot be empty");
        return;
    }
    const lesson = {
        teacherId: req.body.teacherId,
        studentId: req.body.studentId,
        date: req.body.date,
    };
    // run insert query
    const q = "insert into web.lessons set ?";
    sql.query(q, lesson, (err, mysqlres) => {
        if (err) {
            console.log(err);
            res.status(400).send("Create new lesson failed");
            return;
        }
        console.log("Created new lesson", req.body);
        lesson.id = mysqlres.insertId;
        res.status(200).json(lesson);
        return;
    });
};

const cancelLesson = (req, res) => {
    const q = `DELETE FROM web.lessons WHERE id = ${req.query.id}`;
    console.log(q);
    sql.query(q, {}, (err, mysqlres) => {
        if (err) {
            console.log(err);
            res.status(400).send("failed to delete lesson");
            return;
        }
        console.log("deleted the lesson successfully");
        res.status(200).send("deleted the lesson successfully");
        return;
    });
};

module.exports = {
    login,
    logout,
    createNewStudent,
    createNewTeacher,
    searchTeachers,
    getLessonsByStudentId,
    createLesson,
    cancelLesson,
};
